
<input type="file" id="file" />

<p>
  <label>Music Data:</label>
  <span id=""></span>
</p>

<p>
  <label>File Type:</label>
  <span id="filetype"></span>
</p>

<p>
  <label>File Size:</label>
  <span id="filesize"></span>
</p>
