<div class="modal-body">
<div class="form-group">
    <label for="video-url">Paste a Vimeo or YouTube video URL here</label>
    <input class="form-control" id="video" name="video" placeholder="Video URL" type="url">
</div>
<div id="video" style="display: none;">
    <div class="form-group">
        <div id="video-preview"></div>
    </div>
    <div class="form-group">
        <label for="video-title">Caption/Title</label>
        <input class="form-control" id="video-title" maxlength="100" name="video" placeholder="Video Title" type="text">
    </div>
</div>